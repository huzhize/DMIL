package com.routon.plcloud.device.api.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author FireWang
 * @date 2020/4/27 16:09
 */
@Controller
@RequestMapping(value = "/login")
public class LoginController {
    @RequestMapping(value = "/developinfo")
    public String toinfo(){

        //这里返回页面路径
        return "/info";
    }

}
