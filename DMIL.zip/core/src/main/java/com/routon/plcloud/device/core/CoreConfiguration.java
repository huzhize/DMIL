package com.routon.plcloud.device.core;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author FireWang
 * @date 2020/4/26 17:24
 */

@ComponentScan
@Configuration
public class CoreConfiguration {

}
